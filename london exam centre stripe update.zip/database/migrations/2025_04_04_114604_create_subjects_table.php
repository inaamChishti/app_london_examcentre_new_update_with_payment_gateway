<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('subjects', function (Blueprint $table) {
            $table->id();
            $table->string('examBoard')->nullable();
            $table->string('courseType')->nullable();
            $table->string('subjectName')->nullable();
            $table->string('tier')->nullable();
            $table->string('subjectCode')->nullable();
            $table->string('examSession')->nullable();
            $table->string('examTime')->nullable();
            $table->text('examDate')->nullable();
            $table->string('examDay')->nullable();
            $table->string('duration')->nullable();
            $table->string('nea')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('subjects');
    }
};
