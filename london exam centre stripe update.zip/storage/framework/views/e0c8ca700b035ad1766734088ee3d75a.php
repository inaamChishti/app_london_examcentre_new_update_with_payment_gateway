<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Import Offered Subjects</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        .custom-file-label::after { content: "Browse"; }
        .sample-table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }
        .sample-table th, .sample-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .sample-table th { background-color: #f2f2f2; }
        .sample-table tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
</head>
<body>

<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5><i class="fas fa-file-import"></i> Import Offered Subjects</h5>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <?php echo e(session('success')); ?>

                            <?php if(session('imported')): ?>
                                <br>Imported: <?php echo e(session('imported')); ?> records
                            <?php endif; ?>
                            <?php if(session('skipped')): ?>
                                <br>Skipped: <?php echo e(session('skipped')); ?> records
                            <?php endif; ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>)
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="alert alert-info">
                        <strong>Note:</strong> Excel file must have these columns in order:
                        <ol>
                            <li><strong>Entry Code</strong></li>
                            <li><strong>Qualification</strong></li>
                            <li><strong>Description</strong></li>
                            <li><strong>Exam Board</strong></li>
                        </ol>
                    </div>




                    <form action="<?php echo e(url('submit-import-offered-subjects')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="excel_file">Select Excel File</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="excel_file" name="file" required accept=".xlsx,.xls,.csv">
                                <label class="custom-file-label" for="excel_file">Choose file...</label>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-upload"></i> Import
                            </button>
                        </div>
                    </form>
                    <div class="mt-4">
                        <h5>Offered Subjects</h5>
                        <?php if($offered->isEmpty()): ?>
                            <p>No offered subjects found.</p>
                        <?php else: ?>
                            <table class="sample-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Exam Board</th>
                                        <th>Code</th>
                                        <th>Qualification</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $offered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($subject->id); ?></td>
                                            <td><?php echo e($subject->examboard); ?></td>
                                            <td><?php echo e($subject->code); ?></td>
                                            <td><?php echo e($subject->qualification); ?></td>
                                            <td><?php echo e($subject->description); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('offered-subjects.destroy', $subject->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this subject?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        $('.custom-file-input').on('change', function () {
            let fileName = $(this).val().split('\\').pop();
            $(this).next('.custom-file-label').addClass("selected").html(fileName);
        });
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Frobel_Exam_Hub_New_Code  London Exam Centre - app.Stripe\resources\views\import\importPublicPage.blade.php ENDPATH**/ ?>