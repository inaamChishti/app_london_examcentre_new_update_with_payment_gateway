

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row mb-5">
        <div class="col-12">
            <div class="card border-0 shadow-lg overflow-hidden">
                <div class="card-header position-relative py-3" style="background: #F87A14; border-bottom: 4px solid #1976D2;">
                    <div class="d-flex justify-content-between align-items-center">
                        <h2 class="h4 mb-0 text-white">
                            <i class="fas fa-user-graduate me-2" style="color: #ffffff;"></i>
                            <?php echo e($request->first_name ?? 'N/A'); ?> <?php echo e($request->surname ?? ''); ?>

                        </h2>
                        <div class="position-absolute top-0 end-0 px-3 py-1 bg-success text-white rounded-bl-lg">
                            Approved
                        </div>
                    </div>
                </div>

                <div class="card-body p-0">
                    <div class="row g-0">
                        <!-- LEFT SIDEBAR -->
                        <div class="col-lg-4 p-4" style="background-color: #f8fafb;">
                            <div class="text-center mb-4">
                                <?php if(!empty($request->photo_path)): ?>
                                <div class="position-relative d-inline-block">
                                    <img src="<?php echo e(asset($request->photo_path)); ?>"
                                         class="rounded-circle shadow border border-4 border-white"
                                         alt="Profile"
                                         style="width: 150px; height: 150px; object-fit: cover;">
                                    <span class="position-absolute bottom-0 end-0 bg-info p-2 rounded-circle">
                                        <i class="fas fa-check text-white"></i>
                                    </span>
                                </div>
                                <?php else: ?>
                                <div class="rounded-circle bg-light d-flex align-items-center justify-content-center"
                                     style="width: 150px; height: 150px; margin: 0 auto;">
                                    <i class="fas fa-user-graduate text-muted fa-3x"></i>
                                </div>
                                <?php endif; ?>
                                <h4 class="mt-3 mb-0" style="color: #000000;"><?php echo e($request->first_name ?? 'N/A'); ?> <?php echo e($request->surname ?? ''); ?></h4>
                                <p class="text-muted">Student ID: <?php echo e($request->student_id ?? 'N/A'); ?></p>
                            </div>

                            <!-- Personal Details -->
                            <div class="card mb-4 border-0 shadow-sm">
                                <div class="card-header bg-white py-2 border-bottom">
                                    <h5 class="mb-0" style="color: #000000;">
                                        <i class="fas fa-id-card me-2" style="color: #17a2b8;"></i>Personal Details
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <ul class="list-unstyled mb-0">
                                        <li class="mb-2 d-flex"><span class="me-2"><i class="fas fa-calendar-alt" style="color: #007bff;"></i></span> <strong>DOB:</strong> <?php echo e($request->dob ?? 'N/A'); ?></li>
                                        <li class="mb-2 d-flex"><span class="me-2"><i class="fas fa-venus-mars" style="color: #6f42c1;"></i></span> <strong>Gender:</strong> <?php echo e($request->gender ?? 'N/A'); ?></li>
                                        <li class="mb-2 d-flex"><span class="me-2"><i class="fas fa-home" style="color: #28a745;"></i></span> <strong>Address:</strong> <?php echo e($request->address_line1 ?? 'N/A'); ?> <?php if(!empty($request->address_line2)): ?><br><?php echo e($request->address_line2); ?><?php endif; ?></li>
                                        <li class="mb-2 d-flex"><span class="me-2"><i class="fas fa-map-marker-alt" style="color: #dc3545;"></i></span> <strong>Post Code:</strong> <?php echo e($request->postcode ?? 'N/A'); ?></li>
                                        <li class="mb-2 d-flex"><span class="me-2"><i class="fas fa-id-badge" style="color: #ffc107;"></i></span> <strong>ULN:</strong> <?php echo e($request->uln ?? 'N/A'); ?></li>
                                    </ul>
                                </div>
                            </div>

                            <!-- Contact Info -->
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-white py-2 border-bottom">
                                    <h5 class="mb-0" style="color: #000000;">
                                        <i class="fas fa-phone-alt me-2" style="color: #17a2b8;"></i>Contact Information
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <ul class="list-unstyled mb-0">
                                        <li class="mb-2 d-flex"><span class="me-2"><i class="fas fa-mobile-alt" style="color: #007bff;"></i></span> <?php echo e($request->contact_number ?? 'N/A'); ?></li>
                                        <li class="mb-2 d-flex"><span class="me-2"><i class="fas fa-envelope" style="color: #28a745;"></i></span> <?php echo e($request->email ?? 'N/A'); ?></li>
                                        <li class="d-flex"><span class="me-2"><i class="fas fa-exclamation-triangle" style="color: #dc3545;"></i></span> <strong>Emergency:</strong> <?php echo e($request->emergency_contact ?? 'N/A'); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- RIGHT CONTENT -->
                        <div class="col-lg-8 p-4">

                            <!-- Medical & UCI -->
                            <div class="row mb-4">
                                <div class="col-md-6 mb-3 mb-md-0">
                                    <div class="card h-100 border-0 shadow-sm">
                                        <div class="card-header bg-white py-2">
                                            <h5 class="mb-0" style="color: #000000;">
                                                <i class="fas fa-heartbeat me-2" style="color: #dc3545;"></i>Medical Information
                                            </h5>
                                        </div>
                                        <div class="card-body">
                                            <p class="<?php echo e(!empty($request->medical_condition) ? 'text-dark' : 'text-muted'); ?>">
                                                <?php echo e($request->medical_condition ?? 'No medical conditions reported'); ?>

                                            </p>
                                            <?php if($request->access_arrangement): ?>
                                            <div class="mt-3">
                                                <h6 class="text-info"><i class="fas fa-wheelchair me-2" style="color: #6f42c1;"></i>Access Arrangement</h6>
                                                <p><?php echo e($request->access_arrangement_explanation ?? 'No details provided'); ?></p>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card h-100 border-0 shadow-sm">
                                        <div class="card-header bg-white py-2">
                                            <h5 class="mb-0" style="color: #000000;">
                                                <i class="fas fa-id-badge me-2" style="color: #ffc107;"></i>UCI Details
                                            </h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-info bg-opacity-10 p-3 rounded me-3">
                                                    <i class="fas fa-id-card" style="color: #17a2b8;"></i>
                                                </div>
                                                <div>
                                                    <p class="mb-0"><strong>UCI Number</strong></p>
                                                    <p class="mb-0 font-monospace"><?php echo e($request->uci_number ?? 'N/A'); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Exam Details -->
                            <div class="card mb-4 border-0 shadow-sm" style="zoom:0.8;">
                                <div class="card-header bg-white py-2">
                                    <h5 class="mb-0" style="color: #000000;">
                                        <i class="fas fa-clipboard-list me-2" style="color: #007bff;"></i>Exam Details
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <?php if($examDetails->isNotEmpty()): ?>
                                        <div class="table-responsive">
                                            <table class="table table-hover mb-0">
                                                <thead class="table-info">
                                                    <tr>
                                                        <th>Exam Board</th>
                                                        <th>Course Type</th>
                                                        <th>Subject</th>
                                                        <th>Subject Code</th>
                                                        <th>Tier</th>
                                                        <th>NEA</th>
                                                        <th>Date</th>
                                                        <th>Day</th>
                                                        <th>Time</th>
                                                        <th>Duration</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $examDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($exam->exam_board ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->course_type ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->subject_name ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->subject_code ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->tire ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->nea ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->date ? \Carbon\Carbon::make($exam->date)->format('d/m/Y') : 'N/A'); ?></td>
                                                            <td><?php echo e($exam->day ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->time ?? 'N/A'); ?></td>
                                                            <td><?php echo e($exam->duration ?? 'N/A'); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-4">
                                            <i class="fas fa-clipboard-question fa-3x" style="color: #6c757d;"></i>
                                            <p class="text-muted">No exam details recorded</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- SUPPORTING DOCUMENTS + RECEIPTS -->
                            <div class="row">

                                <!-- SUPPORTING DOCUMENTS -->
                                <div class="col-md-6 mb-4">
                                    <div class="card border-0 shadow-sm h-100">
                                        <div class="card-header bg-white py-2">
                                            <h5 class="mb-0" style="color: #000000;">
                                                <i class="fas fa-file-alt me-2" style="color: #17a2b8;"></i>Supporting Documents
                                            </h5>
                                        </div>
                                        <div class="card-body">
                                            <?php if(!empty($request->id_document_path)): ?>
                                            <div class="mb-3">
                                                <h6><i class="fas fa-id-card me-2" style="color: #ffc107;"></i>ID Document</h6>
                                                <?php $encoded = base64_encode($request->id_document_path); ?>
                                                <a href="<?php echo e(route('file.view', ['encoded' => $encoded])); ?>" target="_blank" class="btn btn-sm btn-outline-info">
                                                    <i class="fas fa-eye me-1"></i>View
                                                </a>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(!empty($request->supporting_documents_path)): ?>
                                            <div class="mb-3">
                                                <h6><i class="fas fa-file-pdf me-2" style="color: #dc3545;"></i>Supporting Documents</h6>
                                                <?php $encoded = base64_encode($request->supporting_documents_path); ?>
                                                <a href="<?php echo e(route('file.view', ['encoded' => $encoded])); ?>" target="_blank" class="btn btn-sm btn-outline-info">
                                                    <i class="fas fa-eye me-1"></i>View
                                                </a>
                                            </div>
                                            <?php endif; ?>

                                            <?php
                                                $additional_docs = is_array($request->additional_docs_paths)
                                                    ? $request->additional_docs_paths
                                                    : json_decode($request->additional_docs_paths ?? '[]', true) ?? [];
                                            ?>

                                            <?php if(!empty($additional_docs)): ?>
                                            <div>
                                                <h6><i class="fas fa-file-archive me-2" style="color: #6f42c1;"></i>Additional Documents</h6>
                                                <?php $__currentLoopData = $additional_docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!empty($doc)): ?>
                                                <div class="mb-2">
                                                    <?php $encoded = base64_encode($doc); ?>
                                                    <a href="<?php echo e(route('file.view', ['encoded' => $encoded])); ?>" target="_blank" class="btn btn-sm btn-outline-info">
                                                        <i class="fas fa-file me-1"></i>Document <?php echo e($index + 1); ?>

                                                    </a>
                                                </div>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(empty($request->id_document_path) && empty($request->supporting_documents_path) && empty($additional_docs)): ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-folder-open fa-3x" style="color: #6c757d;"></i>
                                                <p class="text-muted">No documents uploaded</p>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- RECEIPTS - SIRF VIEW ICON -->
                                <div class="col-md-6 mb-4">
                                    <div class="card border-0 shadow-sm h-100">
                                        <div class="card-header bg-white py-2">
                                            <h5 class="mb-0" style="color: #000000;">
                                                <i class="fas fa-receipt me-2" style="color: #28a745;"></i> Receipts
                                            </h5>
                                        </div>
                                        <div class="card-body">

                                            <?php if($payments->isNotEmpty()): ?>
                                                <div class="list-group list-group-flush">
                                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="list-group-item d-flex justify-content-between align-items-center py-2">
                                                            <span class="small text-muted">
                                                                Payment:
                                                                <?php if($pay->amount_received): ?>
                                                                    <strong>£<?php echo e(number_format($pay->amount_received, 2)); ?></strong>
                                                                <?php endif; ?>
                                                            </span>

                                                            <?php if(!empty($pay->receipt_path)): ?>
                                                                <?php $encoded = base64_encode($pay->receipt_path); ?>
                                                                <a href="<?php echo e(route('file.view', ['student_id' => $pay->student_id, 'encoded' => $encoded])); ?>"
                                                                   target="_blank"
                                                                   class="btn btn-sm btn-outline-success"
                                                                   title="View Receipt">
                                                                    <i class="fas fa-eye"></i>
                                                                </a>
                                                            <?php else: ?>
                                                                <span class="text-muted small">—</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php else: ?>
                                                <div class="text-center py-4">
                                                    <i class="fas fa-receipt fa-3x" style="color: #6c757d;"></i>
                                                    <p class="text-muted mt-2">No receipts</p>
                                                </div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- COURSEWORK & PRACTICAL -->
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="card border-0 shadow-sm h-100">
                                        <div class="card-header bg-white py-2">
                                            <h5 class="mb-0" style="color: #000000;">
                                                <i class="fas fa-check-circle me-2" style="color: #28a745;"></i>Coursework & Practical
                                            </h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <h6><i class="fas fa-flask me-2" style="color: #007bff;"></i> Practical Endorsement</h6>
                                                <p><?php echo e($request->practical_endorsement ?? 'N/A'); ?></p>
                                            </div>
                                            <div class="mb-3">
                                                <h6><i class="fas fa-book me-2" style="color: #6f42c1;"></i> Coursework</h6>
                                                <p><?php echo e($request->course_work ?? 'N/A'); ?></p>
                                            </div>
                                            <?php if(!empty($request->course_work_uci)): ?>
                                            <div>
                                                <h6><i class="fas fa-id-card-alt me-2" style="color: #ffc107;"></i> Coursework UCI</h6>
                                                <p><?php echo e($request->course_work_uci); ?></p>
                                            </div>
                                            <?php endif; ?>

                                            <div class="mb-3">
                                                <h6><i class="fas fa-university me-2" style="color: #8e44ad;"></i> Predicted Grades & UCAS Reference</h6>
                                                <p><?php echo e(!empty($request->need_predicted_grades) ? $request->need_predicted_grades : 'N/A'); ?></p>
                                            </div>

                                            <div class="mb-3">
                                                <h6><i class="fas fa-pencil-alt me-2" style="color: #16a085;"></i> Mock Exams</h6>
                                                <p><?php echo e(!empty($request->need_mock_exams) ? $request->need_mock_exams : 'N/A'); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- FOOTER -->
                <div class="card-footer bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="text-muted small">
                            <i class="fas fa-clock me-1" style="color: #6c757d;"></i>
                            Created: <?php echo e(isset($request->created_at) ? $request->created_at->format('M d, Y') : 'N/A'); ?> |
                            Last Updated: <?php echo e(isset($request->updated_at) ? $request->updated_at->format('M d, Y') : 'N/A'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body { background-color: #f8fafb; }
    .card { transition: all 0.3s ease; border-radius: 0.75rem; }
    .card:hover { box-shadow: 0 10px 25px rgba(87, 175, 191, 0.2); transform: translateY(-2px); }
    .card-header { border-radius: 0.75rem 0.75rem 0 0 !important; }
    .btn-outline-success { color: #28a745; border-color: #28a745; }
    .btn-outline-success:hover { background-color: #28a745; color: white; }
    h2, h3, h4, h5, h6 { color: #000000 !important; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Frobel_Exam_Hub_New_Code  London Exam Centre - app.Stripe\resources\views\student\viewStudent.blade.php ENDPATH**/ ?>