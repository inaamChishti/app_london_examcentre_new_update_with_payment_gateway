

<?php $__env->startSection('content'); ?>
<style>
    .rr-page { padding: 20px; }

    .rr-card {
        background: #fff;
        border-radius: 15px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        overflow: hidden;
        margin-bottom: 24px;
    }

    .rr-card-header {
        background: #F87A14;
        padding: 18px 25px;
        border-bottom: 4px solid #1976D2;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 10px;
    }    .rr-card-header h4 {
        margin: 0;
        font-weight: 700;
        font-size: 1.2rem;
        color: #fff;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .session-badge {
        background: rgba(0,0,0,0.15);
        color: #fff;
        font-size: 0.78rem;
        font-weight: 600;
        padding: 3px 10px;
        border-radius: 20px;
    }

    .rr-filter-wrap {
        padding: 20px 25px;
        background: #FFF3E0;
        border-bottom: 1px solid #FFCC80;
        display: flex;
        align-items: flex-end;
        gap: 16px;
        flex-wrap: wrap;
    }
    .rr-filter-wrap label {
        font-weight: 600;
        font-size: 0.88rem;
        color: #555;
        margin-bottom: 5px;
        display: block;
    }
    .rr-filter-wrap select {
        min-width: 260px;
        border: 1px solid #FFCC80;
        border-radius: 8px;
        padding: 9px 13px;
        font-size: 0.9rem;
        background: #fff;
        color: #333;
        cursor: pointer;
    }
    .rr-filter-wrap select:focus {
        outline: none;
        border-color: #F87A14;
        box-shadow: 0 0 0 0.2rem rgba(248,122,20,0.3);
    }
    .btn-filter {
        background: #333;
        color: #F87A14;
        border: none;
        border-radius: 8px;
        padding: 9px 22px;
        font-weight: 600;
        font-size: 0.88rem;
        cursor: pointer;
        transition: background 0.2s;
    }
    .btn-filter:hover { background: #111; color: #E66A00; }

    .rr-stats-bar {
        padding: 14px 25px;
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        align-items: center;
        border-bottom: 1px solid #f0f0f0;
    }
    .stat-chip {
        background: #FFF3E0;
        border: 1px solid #FFCC80;
        border-radius: 20px;
        padding: 4px 14px;
        font-size: 0.8rem;
        color: #555;
        font-weight: 600;
    }
    .stat-chip span { color: #F87A14; font-weight: 700; }

    .rr-table-wrap { padding: 16px 25px 25px; }

    .rr-table {
        width: auto;
        min-width: 500px;
        border-collapse: collapse;
    }
    .rr-table thead th {
        background: #FFF3E0;
        color: #555;
        font-size: 0.78rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        padding: 8px 14px;
        border-bottom: 2px solid #F87A14;
        white-space: nowrap;
    }
    .rr-table tbody tr { transition: background 0.15s; }
    .rr-table tbody tr:hover { background: #FFF3E0; }
    .rr-table tbody td {
        padding: 8px 14px;
        border-bottom: 1px solid #f0f0f0;
        font-size: 0.88rem;
        color: #444;
        vertical-align: middle;
        white-space: nowrap;
    }
    .rr-table tbody tr:last-child td { border-bottom: none; }

    .rr-empty {
        text-align: center;
        padding: 50px 20px;
        color: #aaa;
    }
    .rr-empty i { font-size: 3rem; color: #F87A14; margin-bottom: 12px; display: block; }
    .rr-empty p { font-size: 1rem; margin: 0; }

    .back-link {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        color: #555;
        font-size: 0.88rem;
        font-weight: 600;
        text-decoration: none;
        padding: 7px 16px;
        border: 1px solid #ddd;
        border-radius: 8px;
        background: #fff;
        transition: background 0.2s;
    }
    .back-link:hover { background: #f5f5f5; color: #333; text-decoration: none; }
</style>

<div class="rr-page">

    
    <div style="margin-bottom: 16px;">
        <a href="<?php echo e(route('referrals.index')); ?>" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Referrals
        </a>
    </div>

    <div class="rr-card">

        
        <div class="rr-card-header">
            <h4>
                <i class="fas fa-chart-bar"></i>
                Referral Report
                <?php if($currentSession): ?>
                    <span class="session-badge"><?php echo e($currentSession); ?></span>
                <?php endif; ?>
            </h4>
        </div>

        
        <form method="GET" action="<?php echo e(route('referrals.report')); ?>">
            <div class="rr-filter-wrap">
                <div>
                    <label for="referralSelect">Select Referral</label>
                    <select name="referral" id="referralSelect" onchange="this.form.submit()">
                        <option value="">-- Choose a referral --</option>
                        <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ref->name); ?>"
                                <?php echo e($selectedReferral == $ref->name ? 'selected' : ''); ?>>
                                <?php echo e($ref->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if($selectedReferral): ?>
                    <a href="<?php echo e(route('referrals.report')); ?>" class="back-link" style="margin-bottom:1px;">
                        <i class="fas fa-times"></i> Clear
                    </a>
                <?php endif; ?>
            </div>
        </form>

        <?php if($selectedReferral): ?>

            
            <div class="rr-stats-bar">
                <div class="stat-chip">Referral: <span><?php echo e($selectedReferral); ?></span></div>
                <div class="stat-chip">Session: <span><?php echo e($currentSession ?? 'N/A'); ?></span></div>
                <div class="stat-chip">Total Students: <span><?php echo e($totalCount); ?></span></div>
            </div>

            
            <div class="rr-table-wrap">
                <?php if($students->isEmpty()): ?>
                    <div class="rr-empty">
                        <i class="fas fa-users"></i>
                        <p>No students found for referral <strong><?php echo e($selectedReferral); ?></strong> in the current session.</p>
                    </div>
                <?php else: ?>
                    <table class="rr-table">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Full Name</th>
                                <th>UCI Number</th>
                                <th>Email</th>
                                <th>Contact</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($student->student_id); ?></td>
                                <td><?php echo e($student->first_name); ?> <?php echo e($student->surname); ?></td>
                                <td><?php echo e($student->uci_number ?? '—'); ?></td>
                                <td><?php echo e($student->email ?? '—'); ?></td>
                                <td><?php echo e($student->contact_number ?? '—'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

        <?php else: ?>
            <div class="rr-empty">
                <i class="fas fa-share-alt"></i>
                <p>Select a referral above to see the students associated with it in the current session.</p>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Frobel_Exam_Hub_New_Code  London Exam Centre - app.Stripe\resources\views\referrals\report.blade.php ENDPATH**/ ?>